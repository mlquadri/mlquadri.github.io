$wshShell = new-object -com wscript.shell
$wshShell.SendKeys([char]179)