/**
 * Write a description of class Player here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Player
{
    // instance variables - replace the example below with your own
    private Object file;
    /**
     * Constructor for objects of class Player
     */
    public Player(Object file)
    {
        this.file = file;
    }

    /**
     * An example of a method - replace this comment with your own
     */
    public void play()
    {}
    
    /**
     * An example of a method - replace this comment with your own
     */
    public void pause()
    {}
    
    /**
     * An example of a method - replace this comment with your own
     */
    public void stop()
    {
        file = null;
    }
    
    /**
     * An example of a method - replace this comment with your own
     */
    public void fastForword()
    {
        //code
    }
    
    /**
     * An example of a method - replace this comment with your own
     */
public void reWind()
    {
        //code
    }
}
